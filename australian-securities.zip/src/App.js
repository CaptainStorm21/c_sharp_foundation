import React from 'react';
import logo from './logo.svg';
import './App.css';
import client from './utils/client'

function App() {
    const [state, setState] = React.useReducer(
        (state, newState) => ({ ...state, ...newState }),
        {}
    )
    const handleSubmit = async (e) => {
        console.log(state);
        e.preventDefault()
        //alert(JSON.stringify(state))
        try {
            let url = '/api/Login'
            let { data } = await client.post(url, state)
            alert(JSON.stringify(data))

        } catch (err) {
            alert(err.message)
        }
        
    }
    const handleChange = e => {
        e.preventDefault()
        const target = e.target;
        let name = target.name
        setState({ [name]: target.value })
        console.log({ [name]: target.value })
        ///alert(JSON.stringify(e.target))
    }
  return (
    <div className="App">
      <header className="App-header">
       
       
              <form onSubmit={handleSubmit}>
                  <input type="text" name="Username" onChange={handleChange} /><br/>
                  <input type="password" name="Password" onChange={handleChange} /><br/>
                  <button type="submit">Login</button>
                  </form>
      </header>
    </div>
  );
}

export default App;
