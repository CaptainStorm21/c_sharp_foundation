import axios from 'axios'

const client = axios.create({
    baseURL: 'https://aslonline-api.azurewebsites.net',
    headers: {
        Authorization: ''
    }
})

export default client